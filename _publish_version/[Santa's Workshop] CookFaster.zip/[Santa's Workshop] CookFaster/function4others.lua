_G.Santas_CookFaster = _G.Santas_CookFaster or {}
Santas_CookFaster.options_menu = "Santas_CookFaster_menu"
Santas_CookFaster.ModPath = ModPath
Santas_CookFaster.SaveFile = Santas_CookFaster.SaveFile or SavePath .. "Santas_CookFaster.txt"
Santas_CookFaster.settings = Santas_CookFaster.settings or {}

function Santas_CookFaster:Reset()
	self.settings = {
		Enable = true,
		Cook_Time = 1,
	}
	self:Save()
end

function Santas_CookFaster:Load()
	local file = io.open(self.SaveFile, "r")
	if file then
		for key, value in pairs(json.decode(file:read("*all"))) do
			self.settings[key] = value
		end
		file:close()
	else
		self:Reset()
	end
end

function Santas_CookFaster:Save()
	local file = io.open(self.SaveFile, "w+")
	if file then
		file:write(json.encode(self.settings))
		file:close()
	end
end

Santas_CookFaster:Load()


Hooks:Add("LocalizationManagerPostInit", "Santas_CookFaster_loc", function(loc)
	LocalizationManager:add_localized_strings({
		["Santas_CookFaster_menu_title"] = "[Santa's Workshop] CookFaster",
		["Santas_CookFaster_menu_desc"] = "",
		["Santas_CookFaster_menu_Enable_title"] = "Enable",
		["Santas_CookFaster_menu_Enable_desc"] = "",
		["Santas_CookFaster_menu_Cook_Time_title"] = "Cook Time",
		["Santas_CookFaster_menu_Cook_Time_desc"] = "",
	})
end)

Hooks:Add("MenuManagerSetupCustomMenus", "Santas_CookFaster_Options", function(menu_manager, nodes)
	MenuHelper:NewMenu(Santas_CookFaster.options_menu)
end)

Hooks:Add("MenuManagerPopulateCustomMenus", "Santas_CookFaster_Options", function(menu_manager, nodes)
	MenuCallbackHandler.Santas_CookFaster_menu_Cook_Time_callback = function(self, item)
		Santas_CookFaster.settings.Cook_Time = math.floor(item:value())
		Santas_CookFaster:Save()
	end
	MenuHelper:AddSlider({
		id = "Santas_CookFaster_menu_Cook_Time_callback",
		title = "Santas_CookFaster_menu_Cook_Time_title",
		callback = "Santas_CookFaster_menu_Cook_Time_callback",
		value = Santas_CookFaster.settings.Cook_Time,
		min = 1,
		max = 120,
		step = 1,
		show_value = true,
		menu_id = Santas_CookFaster.options_menu,  
	})
	MenuCallbackHandler.Santas_CookFaster_menu_Enable_callback = function(self, item)
		Santas_CookFaster.settings.Enable = item:value() == "on" and true or false
		Santas_CookFaster:Save()
	end
	MenuHelper:AddToggle({
		id = "Santas_CookFaster_menu_Enable_callback",
		title = "Santas_CookFaster_menu_Enable_title",
		callback = "Santas_CookFaster_menu_Enable_callback",
		value = Santas_CookFaster.settings.Enable,
		menu_id = Santas_CookFaster.options_menu,  
	})
end)

Hooks:Add("MenuManagerBuildCustomMenus", "Santas_CookFaster_Options", function(menu_manager, nodes)
	nodes[Santas_CookFaster.options_menu] = MenuHelper:BuildMenu(Santas_CookFaster.options_menu)
	MenuHelper:AddMenuItem(nodes["blt_options"], Santas_CookFaster.options_menu, "Santas_CookFaster_menu_title", "Santas_CookFaster_menu_desc")
end)
