core:module("CoreElementTimer")
core:import("CoreMissionScriptElement")
ElementTimer = ElementTimer or class(CoreMissionScriptElement.MissionScriptElement)

if Global.level_data and Global.level_data.level_id == "cane" then
	Hooks:PreHook(ElementTimer, "on_script_activated", "CookFaster_Santas_Workshop", function(self, ...)
		local Santas_CookFaster = _G.Santas_CookFaster or {}
		if not Santas_CookFaster.settings or not Santas_CookFaster.settings.Enable then return end

		local cook_time = Santas_CookFaster.settings.Cook_Time or 1
		local ids = {
			"132417", "132428", "132717", "132728", "133017", "133028", "133317", "133328", "133617", "133628",
			"133917", "133928", "134217", "134228", "134517", "134528", "134817", "134828", "135117", "135128",
			"135417", "135428", "135717", "135728", "136017", "136028", "136317", "136328", "136617", "136628",
		}
		if table.list_to_set(ids)[tostring(self._id)] and type(self:values().timer) == 'table' then
			self._timer = cook_time
			for i = 1, #self:values().timer do
				self:values().timer[i] = cook_time
			end
		end
	end)
end
