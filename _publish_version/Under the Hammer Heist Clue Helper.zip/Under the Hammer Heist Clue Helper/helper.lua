if Global.level_data and Global.level_data.level_id == "auc" then
	UTHH_clue_helper = UTHH_clue_helper or {}
	UTHH_clue_helper.units = UTHH_clue_helper.units or {}
	UTHH_clue_helper.hud_panel = UTHH_clue_helper.hud_panel or nil

	function UTHH_clue_helper.add_wp(id, pos, icon)
		local wp_name = "UTHH_clue_helper_" .. tostring(id)
		managers.hud:add_waypoint(
			wp_name, {
			icon = icon or "wp_target",
			distance = true,
			position = pos,
			no_sync = true,
			present_timer = 0,
			state = "present",
			radius = 50,
			color = Color.gray,
			blend_mode = "add"
		})
		local waypoint = managers.hud._hud.waypoints[wp_name]
		if waypoint and waypoint.bitmap and waypoint.arrow then
			waypoint.move_speed = 0
			waypoint.arrow:set_alpha(0)

			-- pos.z: 1f<300<2f<750<3f
			if pos.z < 300 then
				waypoint.bitmap:set_color(Color.yellow)
			elseif pos.z < 750 then
				waypoint.bitmap:set_color(Color.orange)
			else
				waypoint.bitmap:set_color(Color.red)
			end

			if not UTHH_clue_helper.hud_panel or not alive(UTHH_clue_helper.hud_panel) then
				UTHH_clue_helper.hud_panel = managers.hud:panel(PlayerBase.PLAYER_INFO_HUD_PD2)
			end

			local callback = function()
				local waypoint = managers.hud and managers.hud._hud and managers.hud._hud.waypoints[wp_name]
				if not waypoint then
					if managers.hud then managers.hud:remove_updator(wp_name) end
					return
				end

				local cam = managers.viewport:get_current_camera()
				if not cam or not alive(UTHH_clue_helper.hud_panel) then return end
				local screen_pos = managers.hud._workspace:world_to_screen(cam, pos)
				local visible = (screen_pos.x > 32 and screen_pos.y > 32 and screen_pos.z > 0) and not UTHH_clue_helper.hud_panel:outside(screen_pos.x + 32, screen_pos.y + 32)
				waypoint.bitmap:set_visible(visible)
			end
			managers.hud:add_updator(wp_name, callback)
		end
	end

	function UTHH_clue_helper.remove_wp(id)
		local wp_name = "UTHH_clue_helper_" .. tostring(id)
		managers.hud:remove_waypoint(wp_name)
	end

	function UTHH_clue_helper.init()
		if next(UTHH_clue_helper.units) then return end

		for _, unit in pairs(managers.interaction._interactive_units or {}) do
			if unit:interaction() and (unit:interaction().tweak_data == "auc_search_clues" or unit:interaction().tweak_data == "auc_search_clues_tablet") then
				if unit:damage() and unit:damage()._variables and unit:damage()._variables.var_clue and unit:damage()._variables.var_clue ~= 0 then
					local type = 0
					if unit:name() == Idstring("units/pd2_dlc_auc/equipment/auc_interactable_folder/auc_interactable_folder") then
						type = 1
					elseif unit:name() == Idstring("units/pd2_dlc_auc/equipment/auc_interactable_kiosk/auc_interactable_desk_kiosk") then
						type = 2
					elseif unit:name() == Idstring("units/pd2_dlc_auc/equipment/auc_interactable_kiosk/auc_interactable_standing_kiosk") then
						type = 3
					end
					UTHH_clue_helper.units[unit:id()] = { unit=unit, pos=unit:interaction():interact_position(), show=false, interacted=false, type=type }
				end
			end
		end

		-- only show 1 unit for each type, choose min(unit.pos.z)
		local show_init = {}
		for id, data in pairs(UTHH_clue_helper.units) do
			if not show_init[data.type] then
				show_init[data.type] = {}
				show_init[data.type].z = math.huge
			end
			if data.pos.z < show_init[data.type].z then
				show_init[data.type].z = data.pos.z
				show_init[data.type].id = id
			end
		end
		for _, data in pairs(show_init) do
			UTHH_clue_helper.units[data.id].show = true
		end
	end

	function UTHH_clue_helper.show()
		for id, data in pairs(UTHH_clue_helper.units) do
			if alive(data.unit) and data.unit:id() ~= -1 then
				--local icon = (data.type == 1 and "equipment_files") or (data.type == 2 and "laptop_objective") or (data.type == 3 and "equipment_hack_ipad") or nil
				local icon = "equipment_files"
				if data.show then
					UTHH_clue_helper.add_wp(id, data.pos, icon)
				end
			end
		end
	end

	function UTHH_clue_helper.hide(u_id)
		if not UTHH_clue_helper.units[u_id] then return end

		local type
		for id, data in pairs(UTHH_clue_helper.units) do
			if u_id and u_id == id then
				type = data.type
				UTHH_clue_helper.remove_wp(id)
			elseif not u_id then
				UTHH_clue_helper.remove_wp(id)
			end
		end

		if type then
			-- there're 2 books, 2 desk-tablets and 2 standing-tablets might have clues, and you can interact 1 unit for each type, and the rest of the same type will hide by system
			-- if player interacted with unit that we didn't show, then the first one is interacted by player, and the second one is hide by system
			local already_interacted = false
			for _, data in pairs(UTHH_clue_helper.units) do
				if data.type == type and id ~= u_id then
					if data.interacted then
						already_interacted = true
					else
						data.show = false
					end
				end
			end
			if not already_interacted then
				UTHH_clue_helper.units[u_id].interacted = true
				UTHH_clue_helper.units[u_id].show = true
			end
		end
	end

	if IngamePlayerBaseState then
		Hooks:PostHook(IngamePlayerBaseState, "set_controller_enabled", "UTHH_clue_helper_1", function(self, ...)
			if next(UTHH_clue_helper.units) == nil then
				UTHH_clue_helper.init()
				UTHH_clue_helper.show()
			end
		end)
	end

	if ObjectInteractionManager then
		Hooks:PreHook(ObjectInteractionManager, "remove_unit", "UTHH_clue_helper_2", function(self, unit, ...)
			if not managers.groupai:state():whisper_mode() and next(UTHH_clue_helper.units) then
				UTHH_clue_helper.hide()
				Hooks:RemovePostHook("UTHH_clue_helper_1")
				Hooks:RemovePreHook("UTHH_clue_helper_2")
				Hooks:RemovePostHook("UTHH_clue_helper_3")
				return
			end
			UTHH_clue_helper.hide(unit:id())
		end)

		Hooks:PostHook(ObjectInteractionManager, "add_unit", "UTHH_clue_helper_3", function(self, unit, ...)
			if alive(unit) and unit:interaction() and unit:interaction().tweak_data == "hold_cut_cable" then
				UTHH_clue_helper.show()
			end
		end)
	end

end
