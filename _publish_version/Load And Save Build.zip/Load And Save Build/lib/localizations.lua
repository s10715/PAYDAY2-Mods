local localization_file_root = ModPath .. "locales/"

Hooks:Add("LocalizationManagerPostInit", "LocalizationManagerPostInit_LoadAndSaveBuild", function(self)
	local loc_files = {
		en = "english.json",
		chs = "schinese.json",
	}
	local lang = BLT.Localization:get_language().language
	local loc_file = loc_files[lang] or loc_files.en
	self:load_localization_file(localization_file_root .. loc_file)
end)