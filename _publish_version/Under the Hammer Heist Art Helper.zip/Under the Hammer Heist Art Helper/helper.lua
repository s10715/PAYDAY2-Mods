if Network:is_server() and Global.level_data and Global.level_data.level_id == "auc" then
	local wp_name = "UTHH_art_helper"

	local function show_waypoint(pos)
		if not pos then return end
		managers.hud:add_waypoint(
			wp_name, {
			icon = 'wp_bag',
			distance = true,
			position = pos,
			no_sync = true,
			present_timer = 0,
			state = "present",
			radius = 50,
			color = Color.gray,
			blend_mode = "add"
		})
		local waypoint = managers.hud._hud.waypoints[wp_name]
		if waypoint and waypoint.bitmap and waypoint.arrow then
			waypoint.move_speed = 0
			waypoint.arrow:set_alpha(0)

			local callback = function()
				local waypoint = managers.hud and managers.hud._hud and managers.hud._hud.waypoints[wp_name]
				if not waypoint then
					if managers.hud then managers.hud:remove_updator(wp_name) end
					return
				end

				local hud_panel = managers.hud:panel(PlayerBase.PLAYER_INFO_HUD_PD2)
				local cam = managers.viewport:get_current_camera()
				if not hud_panel or not alive(hud_panel) or not cam then return end
				local screen_pos = managers.hud._workspace:world_to_screen(cam, pos)
				local visible = (screen_pos.x > 32 and screen_pos.y > 32 and screen_pos.z > 0) and not hud_panel:outside(screen_pos.x + 32, screen_pos.y + 32)
				waypoint.bitmap:set_visible(visible)
			end
			managers.hud:add_updator(wp_name, callback)
		end
	end

	local function hide_waypoint()
		managers.hud:remove_waypoint(wp_name)
	end

	local function find_correct_art_piece()
		if managers and managers.hud and managers.hud._hud and managers.hud._hud.waypoints and managers.hud._hud.waypoints[wp_name] then
			return true
		end

		if managers and managers.mission and managers.mission:script("default") and managers.mission:script("default")._elements then
			local elements = managers.mission:script("default")._elements
			local good_id = elements[101633] and elements[101633]._values and elements[101633]._values.on_executed and elements[101633]._values.on_executed[1] and elements[101633]._values.on_executed[1].id
			if not good_id then return end

			local good_name = tostring(managers.mission:script("default")._elements[good_id]._editor_name)
			local key = ""
			if string.find(good_name, "flowerless") then
				key = "flowerless"
			elseif string.find(good_name, "counterway") then
				key = "counterway"
			elseif string.find(good_name, "hotdrop") then
				key = "hotdrop"
			elseif string.find(good_name, "anomaly") then
				key = "anomaly"
			end

			for _, script in pairs(managers.mission._scripts or {}) do
				for _, element in pairs(script:elements()) do
					if element._editor_name == "waypoint_loot_" .. tostring(key) and element._values and element._values.position then
						for _, unit in pairs(World:find_units_quick("all") or {}) do
							if alive(unit) and unit.interaction and unit:interaction() and unit:interaction():interact_position() and (unit:interaction().tweak_data == "hold_cut_cable" or unit:interaction().tweak_data == "pick_lock_easy_no_skill") then
								if mvector3.distance(element._values.position, unit:interaction():interact_position()) < 100 then
									show_waypoint(element._values.position)
									return true
								end
							end
						end
					end
				end
			end
		end
		return false
	end

	if HUDManager then
		Hooks:PostHook(HUDManager, "update", "UTHH_art_helper_1", function(...)
			if find_correct_art_piece() then
				Hooks:RemovePostHook("UTHH_art_helper_1")
			end
		end)
	end

	if ObjectInteractionManager then
		Hooks:PreHook(ObjectInteractionManager, "remove_unit", "UTHH_art_helper_2", function(self, unit, ...)
			if managers and managers.groupai and managers.groupai:state() and not managers.groupai:state():whisper_mode() then
				hide_waypoint()
				Hooks:RemovePreHook("UTHH_art_helper_2")
				return
			end
		end)
	end
end
